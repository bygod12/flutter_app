package com.example.untitled1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
