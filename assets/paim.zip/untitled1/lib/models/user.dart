class User {
  int idUser;
  String aluNome;
  String aluSenha;
  String aluEmail;

  User({required this.idUser, required this.aluNome, required this.aluSenha, required this.aluEmail});

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      idUser: json['idUser'],
      aluNome: json['aluNome'],
      aluSenha: json['aluSenha'],
      aluEmail: json['aluEmail'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'idUser': idUser,
      'aluNome': aluNome,
      'aluSenha': aluSenha,
      'aluEmail': aluEmail,
    };
  }
}