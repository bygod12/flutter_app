import 'package:untitled1/models/user.dart';

class Refeicao {
  int idRefeicoes;
  List<User> user;
  String nome;
  DateTime data;
  int total_gordura;
  int total_calorias;
  int total_carboidratos;
  int total_fibras;
  int total_proteinas;

  Refeicao({
    required this.idRefeicoes,
    required this.user,
    required this.nome,
    required this.data,
    required this.total_gordura,
    required this.total_calorias,
    required this.total_carboidratos,
    required this.total_fibras,
    required this.total_proteinas,
  });

  factory Refeicao.fromJson(Map<String, dynamic> json) {
    return Refeicao(
      idRefeicoes: json['idRefeicoes'],
      user: json['user'],
      nome: json['nome'],
      data: DateTime.parse(json['data']),
      total_gordura: json['total_gordura'],
      total_calorias: json['total_calorias'],
      total_carboidratos: json['total_carboidratos'],
      total_fibras: json['total_fibras'],
      total_proteinas: json['total_proteinas'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'idRefeicoes': idRefeicoes,
      'user': user,
      'nome': nome,
      'data': data.toIso8601String(),
      'total_gordura': total_gordura,
      'total_calorias': total_calorias,
      'total_carboidratos': total_carboidratos,
      'total_fibras': total_fibras,
      'total_proteinas': total_proteinas,
    };
  }
}
