class Alimento {
  int idAlimentos;
  String nome;
  int calorias;
  int carboidratos;
  int proteina;
  int gordura;
  int fibras;

  Alimento({
    required this.idAlimentos,
    required this.nome,
    required this.calorias,
    required this.carboidratos,
    required this.proteina,
    required this.gordura,
    required this.fibras,
  });

  factory Alimento.fromJson(Map<String, dynamic> json) {
    return Alimento(
      idAlimentos: json['idAlimentos'],
      nome: json['nome'],
      calorias: json['calorias'],
      carboidratos: json['carboidratos'],
      proteina: json['proteina'],
      gordura: json['gordura'],
      fibras: json['fibras'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'idAlimentos': idAlimentos,
      'nome': nome,
      'calorias': calorias,
      'carboidratos': carboidratos,
      'proteina': proteina,
      'gordura': gordura,
      'fibras': fibras,
    };
  }
}
