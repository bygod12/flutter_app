import 'package:flutter/material.dart';
import 'package:untitled1/views/screens/ui/refeicoes.dart';

class FoodDetailsScreen extends StatelessWidget {
  final String foodName;
  final double portions;
  final double carbs;
  final double fats;
  final double proteins;
  final double fibers;
  final double calories;
  final double total;
  final List<String> portionOptions = ['grama', 'kilo', 'miligrama'];
  String selectedPortion = 'grama';

  FoodDetailsScreen({
    this.foodName = 'Alimento Desconhecido',
    this.portions = 1.0,
    this.carbs = 0.0,
    this.fats = 0.0,
    this.proteins = 0.0,
    this.fibers = 0.0,
    this.calories = 0.0,
    this.total = 0.0,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text(
          'Detalhes do Alimento',
          style: TextStyle(
            color: Colors.black,
          ),
        ),
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: Colors.black,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.all(16.0),
          padding: EdgeInsets.all(16.0),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                blurRadius: 10,
                offset: Offset(0, 5),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                foodName,
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 16,width: 10),
              Container(
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.black), // Adiciona a borda ao Container
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Padding(
                        padding: EdgeInsets.only(left: 8), // Espaço à esquerda do TextField
                        child: TextField(
                          style: TextStyle(color: Colors.black),
                          keyboardType: TextInputType.number, // Permite apenas números
                          decoration: InputDecoration(
                            hintText: 'Quantidade', // Adiciona um texto de dica
                            hintStyle: TextStyle(color: Colors.black54),
                            border: InputBorder.none, // Remove a borda do TextField
                          ),
                        ),
                      ),
                    ),
                    DropdownButton<String>(
                      value: selectedPortion,
                      icon: Icon(Icons.arrow_drop_down, color: Colors.black),
                      iconSize: 24,
                      elevation: 16,
                      style: TextStyle(color: Colors.black, fontSize: 18),
                      underline: Container(
                        height: 2,
                        color: Colors.black,
                      ),
                      items: portionOptions.map((String portion) {
                        return DropdownMenuItem<String>(
                          value: portion,
                          child: Text(portion),
                        );
                      }).toList(),
                      onChanged: (String? newValue) {
                        if (newValue != null) {
                          selectedPortion = newValue;
                          // Faça algo com a porção selecionada aqui
                        }
                      },
                    ),
                  ],
                ),
              ),

              SizedBox(height: 16),
              buildDetailRow('Calorias', calories.toStringAsFixed(2)),
              buildDetailRow('Proteínas (g)', proteins.toStringAsFixed(2)),
              buildDetailRow('Carboidratos (g)', carbs.toStringAsFixed(2)),
              buildDetailRow('Fibras (g)', fibers.toStringAsFixed(2)),
              buildDetailRow('Gorduras (g)', fats.toStringAsFixed(2)),
              SizedBox(height: 16),
              Divider(),
              buildDetailRow('Total', total.toStringAsFixed(2), fontSize: 20),
              SizedBox(height: 16),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ListRefeicoes(),
                    ),
                  );

                },
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(50),
                  ),
                  primary: Colors.blueGrey,
                  minimumSize: Size(double.infinity, 50),
                ),
                child: Text(
                  'Cadastrar alimento à refeição',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildDetailRow(String label, String value, {double fontSize = 16.0}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: fontSize,
          ),
        ),
        Text(
          value,
          style: TextStyle(
            fontSize: fontSize,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }
}
